extends CanvasLayer
# Black and white dialogue box with a typewriter effect and choices.
#
# How to use it from any script:
#   var box = preload("res://scripts/dialogue_box.gd").new()
#   add_child(box)
#   await box.say("Delivery guy", "Wesh frero.")     # waits for a click / Space / Enter
#   var i = await box.choose(["Yes", "No"])          # returns 0 for the first choice, 1 for the second...
#   box.close()
#
# While it is open it joins the group "note_open", so hovering over objects
# and the game clock are paused (same as notes and the phone).

signal _advanced
signal _chosen(index)

@export var chars_per_second := 42.0
@export var font_size := 22
@export var name_font_size := 20
@export var box_margin := 40.0
@export var box_bottom_margin := 30.0
@export var box_color := Color(0, 0, 0, 0.93)
@export var border_color := Color(0.85, 0.85, 0.85)
@export var border_width := 2
@export var text_color := Color(1, 1, 1)
@export var narration_color := Color(0.62, 0.62, 0.62)
@export var name_color := Color(0.8, 0.8, 0.8)

var root: Control
var panel: PanelContainer
var name_label: Label
var text_label: Label
var hint_label: Label
var choice_box: VBoxContainer

var typing := false
var waiting := false
var choosing := false
var type_tween: Tween


func _ready():
	layer = 70
	_build()
	root.visible = false


# ====================== BUILD ======================
func _flat(bg: Color, border: Color, margin: float) -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(border_width)
	s.set_corner_radius_all(0)
	s.content_margin_left = margin
	s.content_margin_right = margin
	s.content_margin_top = margin * 0.7
	s.content_margin_bottom = margin * 0.7
	return s


func _build():
	root = Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_STOP     # clicks do not reach the room underneath
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	panel = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _flat(box_color, border_color, 20))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(panel)
	panel.anchor_left = 0.0
	panel.anchor_right = 1.0
	panel.anchor_top = 1.0
	panel.anchor_bottom = 1.0
	panel.offset_left = box_margin
	panel.offset_right = -box_margin
	panel.offset_bottom = -box_bottom_margin
	panel.offset_top = -box_bottom_margin - 150.0
	panel.grow_vertical = Control.GROW_DIRECTION_BEGIN   # grows upwards when choices appear

	var v = VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(v)

	name_label = Label.new()
	name_label.add_theme_font_size_override("font_size", name_font_size)
	name_label.add_theme_color_override("font_color", name_color)
	name_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(name_label)

	text_label = Label.new()
	text_label.add_theme_font_size_override("font_size", font_size)
	text_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text_label.custom_minimum_size = Vector2(0, 66)
	text_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(text_label)

	choice_box = VBoxContainer.new()
	choice_box.add_theme_constant_override("separation", 6)
	v.add_child(choice_box)

	hint_label = Label.new()
	hint_label.text = "click  >"
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	hint_label.add_theme_font_size_override("font_size", 14)
	hint_label.add_theme_color_override("font_color", narration_color)
	hint_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(hint_label)


# ====================== OPEN / CLOSE ======================
func _open():
	if not root.visible:
		root.visible = true
		add_to_group("note_open")


func close():
	if type_tween != null and type_tween.is_valid():
		type_tween.kill()
	typing = false
	waiting = false
	choosing = false
	_clear_choices()
	root.visible = false
	remove_from_group("note_open")


func is_open() -> bool:
	return root != null and root.visible


# ====================== SAY ======================
# speaker = "" means narration (grey text, no name)
func say(speaker: String, text: String) -> void:
	_open()
	_clear_choices()
	name_label.text = speaker
	name_label.visible = speaker != ""
	text_label.text = text
	text_label.add_theme_color_override("font_color", text_color if speaker != "" else narration_color)
	text_label.visible_characters = 0
	hint_label.visible = false

	typing = true
	waiting = false
	if type_tween != null and type_tween.is_valid():
		type_tween.kill()
	type_tween = create_tween()
	type_tween.tween_property(text_label, "visible_characters", text.length(), text.length() / chars_per_second)
	type_tween.finished.connect(_on_typed)

	await _advanced


func _on_typed():
	typing = false
	waiting = true
	text_label.visible_characters = -1
	hint_label.visible = true


# ====================== CHOOSE ======================
func choose(options: Array) -> int:
	_open()
	_clear_choices()
	hint_label.visible = false
	for i in options.size():
		choice_box.add_child(_make_choice(i, str(options[i])))
	choosing = true
	var picked: int = await _chosen
	choosing = false
	_clear_choices()
	return picked


func _make_choice(index: int, label: String) -> Button:
	var b = Button.new()
	b.text = "  " + label
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", font_size - 2)
	b.add_theme_color_override("font_color", text_color)
	b.add_theme_color_override("font_hover_color", Color.BLACK)
	b.add_theme_color_override("font_pressed_color", Color.BLACK)
	b.add_theme_stylebox_override("normal", _flat(Color(0, 0, 0, 0), Color(0.45, 0.45, 0.45), 12))
	b.add_theme_stylebox_override("hover", _flat(Color(0.9, 0.9, 0.9), Color(1, 1, 1), 12))
	b.add_theme_stylebox_override("pressed", _flat(Color(0.9, 0.9, 0.9), Color(1, 1, 1), 12))
	b.pressed.connect(_on_choice_pressed.bind(index))
	return b


func _on_choice_pressed(index: int):
	if choosing:
		_chosen.emit(index)


func _clear_choices():
	for c in choice_box.get_children():
		choice_box.remove_child(c)
		c.queue_free()


# ====================== INPUT ======================
func _input(event):
	if not is_open() or choosing:
		return
	var go := false
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		go = true
	elif event is InputEventKey and event.pressed and not event.echo and (event.keycode == KEY_SPACE or event.keycode == KEY_ENTER):
		go = true
	if not go:
		return
	get_viewport().set_input_as_handled()
	if typing:
		if type_tween != null and type_tween.is_valid():
			type_tween.kill()
		_on_typed()
	elif waiting:
		waiting = false
		_advanced.emit()
