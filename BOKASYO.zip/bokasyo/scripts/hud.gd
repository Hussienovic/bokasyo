extends Node

signal stat_changed(stat_name, value)
signal stat_empty(stat_name)
signal money_changed(amount)
signal objective_changed(text)
signal item_added(item_id)
signal item_removed(item_id)
signal item_opened(item_id)
signal flag_changed(flag_name, value)

# ---------------- LOOK (all panels) ----------------
@export_group("Look")
@export var font: Font
@export var font_size := 18
@export var text_color := Color(0.82, 0.8, 0.74)               # bone / old paper
@export var margin := Vector2(15, 15)                           # distance from the screen edges
@export var panel_color := Color(0.03, 0.03, 0.035, 0.8)
@export var panel_border_color := Color(0.28, 0.27, 0.25)
@export var panel_border_width := 1
@export var panel_corner_radius := 2
@export var panel_padding := 10
@export var panel_picture: Texture2D           # picture for ALL boxes that have no picture of their own (see Pictures)
@export var panel_picture_margin := 16         # edge size kept when the picture stretches

# ---------------- PICTURES (stretch to the box) ----------------
@export_group("Pictures (stretch to the box)")
@export var stats_picture: Texture2D           # box with the bars (top right)
@export var objective_picture: Texture2D       # box with the objective (bottom left)
@export var inventory_picture: Texture2D       # box around all the slots (bottom center)
@export var slot_picture: Texture2D            # one slot
@export var popup_picture: Texture2D           # window that opens when you click an item
@export var popup_close_picture: Texture2D     # the close button of that window
@export var bar_background_picture: Texture2D  # empty part of a bar
@export var bar_fill_picture: Texture2D        # full part of a bar. It gets the stat color. Use white in Stat Colors to keep your colors

# ---------------- MY DESIGNS (you set size and position) ----------------
# Design 1 is BEHIND the text. Design 2 is ON TOP of the text.
# Size 0,0 = fits the whole box. Type only a width (like 200,0) to keep the picture shape.
# Offset moves the picture. Positive = right and down.
@export_group("My Designs (size and position)")
@export var plain_box_with_designs := false    # off = the plain dark box is hidden when a box has a design

@export_subgroup("Stats box (top right)")
@export var stats_design_1: Texture2D
@export var stats_design_1_size := Vector2.ZERO
@export var stats_design_1_offset := Vector2.ZERO
@export var stats_design_2: Texture2D
@export var stats_design_2_size := Vector2.ZERO
@export var stats_design_2_offset := Vector2.ZERO

@export_subgroup("Objective box (bottom left)")
@export var objective_design_1: Texture2D
@export var objective_design_1_size := Vector2.ZERO
@export var objective_design_1_offset := Vector2.ZERO
@export var objective_design_2: Texture2D
@export var objective_design_2_size := Vector2.ZERO
@export var objective_design_2_offset := Vector2.ZERO

@export_subgroup("Inventory box (bottom center)")
@export var inventory_design_1: Texture2D
@export var inventory_design_1_size := Vector2.ZERO
@export var inventory_design_1_offset := Vector2.ZERO
@export var inventory_design_2: Texture2D
@export var inventory_design_2_size := Vector2.ZERO
@export var inventory_design_2_offset := Vector2.ZERO

@export_subgroup("Every slot")
@export var slot_design_1: Texture2D
@export var slot_design_1_size := Vector2.ZERO
@export var slot_design_1_offset := Vector2.ZERO
@export var slot_design_2: Texture2D
@export var slot_design_2_size := Vector2.ZERO
@export var slot_design_2_offset := Vector2.ZERO

@export_subgroup("Item window")
@export var popup_design_1: Texture2D
@export var popup_design_1_size := Vector2.ZERO
@export var popup_design_1_offset := Vector2.ZERO
@export var popup_design_2: Texture2D
@export var popup_design_2_size := Vector2.ZERO
@export var popup_design_2_offset := Vector2.ZERO

# ---------------- STATS (bars, top right) ----------------
@export_group("Stats (top right)")
@export var show_stats := true
@export var stat_names: PackedStringArray = ["Sanity", "Suspicion"]
@export var stat_colors: Array[Color] = [Color(0.8, 0.8, 0.74), Color(0.55, 0.08, 0.08)]
@export var stat_start: PackedFloat32Array = [100.0, 0.0]
@export var stat_bad_when_high: Array[bool] = [false, true]   # false = bad when it drops, true = bad when it rises
@export var stat_max := 100.0
@export var stat_label_width := 80.0
@export var bar_width := 140.0
@export var bar_height := 8.0
@export var bar_corner_radius := 0
@export var bar_background_color := Color(0.1, 0.1, 0.1, 0.9)

# ---------------- MONEY (top right, above the bars) ----------------
@export_group("Money")
@export var show_money := false
@export var money_start := 0
@export var money_prefix := ""
@export var money_suffix := ""

# ---------------- OBJECTIVE (bottom left) ----------------
@export_group("Objective (bottom left)")
@export var show_objective := true
@export var objective_title := "Remember"
@export_multiline var objective_start := ""     # empty = hidden until your story sets one
@export var objective_width := 260.0
@export var objective_title_color := Color(0.55, 0.1, 0.1)

# ---------------- INVENTORY (bottom center) ----------------
@export_group("Inventory (bottom center)")
@export var show_inventory := true
@export var inventory_slots := 5
@export var slot_size := 64.0
@export var slot_spacing := 8
@export var slot_color := Color(0, 0, 0, 0.5)
@export var slot_border_color := Color(0.25, 0.24, 0.22)

# ---------------- ITEM WINDOW (opens when you click a slot) ----------------
@export_group("Item Window")
@export var popup_width := 360.0
@export var popup_icon_size := 96.0
@export var popup_dim_color := Color(0, 0, 0, 0.55)       # dark layer behind the window
@export var popup_title_color := Color(0.65, 0.1, 0.1)
@export var popup_empty_text := "No information."

# ---------------- MESSAGES (whispers) ----------------
@export_group("Messages")
@export var message_font_size := 24
@export var message_color := Color(0.88, 0.85, 0.78)
@export var message_width := 600.0

# ---------------- HORROR EFFECTS ----------------
@export_group("Horror Effects")
@export var vignette_enabled := true           # screen edges go dark when a meter is bad
@export var vignette_color := Color(0.0, 0.0, 0.0)
@export_range(0.0, 1.0) var vignette_strength := 0.85
@export var flicker_enabled := true            # panels flicker when a meter is very bad
@export_range(0.0, 1.0) var flicker_threat := 0.7
@export var danger_color := Color(0.75, 0.05, 0.05)   # bars turn this color when it gets bad

# ---------------- TEST ----------------
@export_group("Test")
@export var test_keys := true    # keys 1 to 5 try the interface. Turn off when you are done testing

const VIGNETTE_SHADER := """
shader_type canvas_item;

uniform float intensity : hint_range(0.0, 1.0) = 0.0;
uniform vec4 tint : source_color = vec4(0.0, 0.0, 0.0, 1.0);

void fragment() {
    float d = distance(UV, vec2(0.5));
    float v = smoothstep(0.3, 0.8, d) * intensity;
    COLOR = vec4(tint.rgb, v);
}
"""

var stats := {}              # stat name -> value
var stat_bars := {}          # stat name -> ProgressBar
var stat_fills := {}         # stat name -> fill style
var stat_base_colors := {}   # stat name -> normal color
var stat_tweens := {}
var money := 0
var objective := ""
var items: Array = []        # each item: {id, name, icon, info}
var flags := {}
var threat_max := 0.0
var flicker_timer := 1.0
var popup_open := false

var layer: CanvasLayer
var vignette_layer: CanvasLayer
var vignette_mat: ShaderMaterial
var vignette_tween: Tween
var message_tween: Tween
var popup_tween: Tween
var stats_panel: PanelContainer
var objective_panel: PanelContainer
var inventory_panel: PanelContainer
var popup_backdrop: ColorRect
var popup_panel: PanelContainer
var popup_icon: TextureRect
var popup_name: Label
var popup_info: Label
var money_label: Label
var objective_label: Label
var message_label: Label
var slots: Array = []


func _ready():
	add_to_group("game_hud")
	money = money_start
	objective = objective_start

	_build_vignette()

	layer = CanvasLayer.new()
	layer.layer = 55
	add_child(layer)

	_build_stats_and_money()
	_build_objective()
	_build_inventory()
	_build_popup()
	_build_message()
	_update_effects()

	get_viewport().size_changed.connect(_layout)
	await get_tree().process_frame
	_layout()
	await get_tree().process_frame
	_layout()


# ====================== STYLES AND HELPERS ======================
func _empty_style(pad: int) -> StyleBox:
	var e = StyleBoxEmpty.new()
	e.set_content_margin_all(pad)
	return e


# pic = the stretching picture of this box. If it is empty, panel_picture is used.
# If that is empty too, a plain box is used (hidden when the box has a design).
func _panel_style(pic: Texture2D = null, has_design: bool = false) -> StyleBox:
	var p = pic if pic != null else panel_picture
	if p != null:
		var t = StyleBoxTexture.new()
		t.texture = p
		t.set_texture_margin_all(panel_picture_margin)
		t.set_content_margin_all(panel_padding)
		return t
	if has_design and not plain_box_with_designs:
		return _empty_style(panel_padding)
	var s = StyleBoxFlat.new()
	s.bg_color = panel_color
	s.border_color = panel_border_color
	s.set_border_width_all(panel_border_width)
	s.set_corner_radius_all(panel_corner_radius)
	s.set_content_margin_all(panel_padding)
	return s


func _slot_style() -> StyleBox:
	if slot_picture != null:
		var t = StyleBoxTexture.new()
		t.texture = slot_picture
		t.set_content_margin_all(4)
		return t
	if (slot_design_1 != null or slot_design_2 != null) and not plain_box_with_designs:
		return _empty_style(4)
	var s = StyleBoxFlat.new()
	s.bg_color = slot_color
	s.border_color = slot_border_color
	s.set_border_width_all(1)
	s.set_corner_radius_all(2)
	s.set_content_margin_all(4)
	return s


func _make_panel(pic: Texture2D = null, has_design: bool = false) -> PanelContainer:
	var p = PanelContainer.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel", _panel_style(pic, has_design))
	layer.add_child(p)
	return p


func _make_label(color: Color, size: int) -> Label:
	var l = Label.new()
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_color_override("font_color", color)
	l.add_theme_font_size_override("font_size", size)
	if font:
		l.add_theme_font_override("font", font)
	return l


# puts ONE design picture on a box. Call it AFTER the box content is built.
# pad = the space between the box edge and its content (so "fit the box" covers the whole box)
# front = false: behind the text. front = true: on top of the text.
func _add_design(box: Control, tex: Texture2D, pic_size: Vector2, pic_offset: Vector2, pad: float, front: bool):
	if tex == null:
		return

	var wrap = Control.new()
	wrap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(wrap)
	if not front:
		box.move_child(wrap, 0)

	var pic = TextureRect.new()
	pic.texture = tex
	pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	pic.stretch_mode = TextureRect.STRETCH_SCALE
	pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	wrap.add_child(pic)

	var fit = func():
		var s: Vector2 = pic_size
		var ts: Vector2 = tex.get_size()
		if s.x > 0.0 and s.y <= 0.0:
			s.y = s.x * ts.y / ts.x
		elif s.y > 0.0 and s.x <= 0.0:
			s.x = s.y * ts.x / ts.y
		if s.x > 0.0 and s.y > 0.0:
			pic.size = s
			pic.position = pic_offset
		else:
			pic.size = wrap.size + Vector2(pad, pad) * 2.0
			pic.position = Vector2(-pad, -pad) + pic_offset
	wrap.resized.connect(fit)
	fit.call()


# design 1 = behind the text, design 2 = on top of the text
func _add_designs(box: Control, t1: Texture2D, s1: Vector2, o1: Vector2, t2: Texture2D, s2: Vector2, o2: Vector2, pad: float):
	_add_design(box, t1, s1, o1, pad, false)
	_add_design(box, t2, s2, o2, pad, true)


# ====================== VIGNETTE (dark screen edges) ======================
func _build_vignette():
	if not vignette_enabled:
		return
	vignette_layer = CanvasLayer.new()
	vignette_layer.layer = 45
	add_child(vignette_layer)

	var rect = ColorRect.new()
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vignette_layer.add_child(rect)
	rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var sh = Shader.new()
	sh.code = VIGNETTE_SHADER
	vignette_mat = ShaderMaterial.new()
	vignette_mat.shader = sh
	vignette_mat.set_shader_parameter("intensity", 0.0)
	vignette_mat.set_shader_parameter("tint", vignette_color)
	rect.material = vignette_mat


# 0 = safe, 1 = worst, for one stat
func _threat(stat_name: String) -> float:
	if not stats.has(stat_name) or stat_max <= 0.0:
		return 0.0
	var frac = stats[stat_name] / stat_max
	var i = stat_names.find(stat_name)
	var high_is_bad = i >= 0 and i < stat_bad_when_high.size() and stat_bad_when_high[i]
	return frac if high_is_bad else 1.0 - frac


func _update_stat_color(stat_name: String):
	if not stat_fills.has(stat_name):
		return
	var t = _threat(stat_name)
	var c = stat_base_colors[stat_name].lerp(danger_color, smoothstep(0.5, 1.0, t))
	var f = stat_fills[stat_name]
	if f is StyleBoxFlat:
		f.bg_color = c
	else:
		f.modulate_color = c    # picture bar: the picture gets this color


func _update_effects():
	var worst = 0.0
	for n in stat_names:
		worst = maxf(worst, _threat(n))
	threat_max = worst

	if vignette_mat != null:
		var target = pow(worst, 2.0) * vignette_strength
		if vignette_tween != null and vignette_tween.is_valid():
			vignette_tween.kill()
		var from = float(vignette_mat.get_shader_parameter("intensity"))
		vignette_tween = create_tween()
		vignette_tween.tween_method(func(v): vignette_mat.set_shader_parameter("intensity", v), from, target, 1.0)


func _process(delta):
	if not flicker_enabled or threat_max < flicker_threat:
		return
	flicker_timer -= delta
	if flicker_timer <= 0.0:
		flicker_timer = randf_range(0.5, 3.0) * (1.5 - threat_max)   # the worse it is, the more often
		_flicker()


func _flicker():
	for p in [stats_panel, objective_panel, inventory_panel]:
		if p != null and p.visible:
			p.modulate.a = randf_range(0.15, 0.4)
			var tw = create_tween()
			tw.tween_property(p, "modulate:a", 1.0, randf_range(0.1, 0.25))


# ====================== STATS AND MONEY ======================
func _build_stats_and_money():
	stats_panel = _make_panel(stats_picture, stats_design_1 != null or stats_design_2 != null)

	var col = VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", 6)
	stats_panel.add_child(col)

	money_label = _make_label(text_color, font_size)
	money_label.visible = show_money
	col.add_child(money_label)
	_update_money_label()

	for i in stat_names.size():
		var n = stat_names[i]
		var start = stat_start[i] if i < stat_start.size() else stat_max
		var color = stat_colors[i] if i < stat_colors.size() else Color.WHITE
		stats[n] = clampf(start, 0.0, stat_max)

		var row = HBoxContainer.new()
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_theme_constant_override("separation", 8)
		row.visible = show_stats
		col.add_child(row)

		var name_label = _make_label(text_color, font_size - 2)
		name_label.text = n
		name_label.custom_minimum_size.x = stat_label_width
		row.add_child(name_label)

		var bar = ProgressBar.new()
		bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bar.min_value = 0.0
		bar.max_value = stat_max
		bar.value = stats[n]
		bar.show_percentage = false
		bar.custom_minimum_size = Vector2(bar_width, bar_height)
		bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER

		var bg: StyleBox
		if bar_background_picture != null:
			var bt = StyleBoxTexture.new()
			bt.texture = bar_background_picture
			bg = bt
		else:
			var bf = StyleBoxFlat.new()
			bf.bg_color = bar_background_color
			bf.set_corner_radius_all(bar_corner_radius)
			bg = bf

		var fill: StyleBox
		if bar_fill_picture != null:
			var ft = StyleBoxTexture.new()
			ft.texture = bar_fill_picture
			fill = ft
		else:
			var ff = StyleBoxFlat.new()
			ff.bg_color = color
			ff.set_corner_radius_all(bar_corner_radius)
			fill = ff

		bar.add_theme_stylebox_override("background", bg)
		bar.add_theme_stylebox_override("fill", fill)

		row.add_child(bar)
		stat_bars[n] = bar
		stat_fills[n] = fill
		stat_base_colors[n] = color
		_update_stat_color(n)

	_add_designs(stats_panel, stats_design_1, stats_design_1_size, stats_design_1_offset, stats_design_2, stats_design_2_size, stats_design_2_offset, panel_padding)
	stats_panel.visible = show_money or (show_stats and stat_names.size() > 0)


func set_stat(stat_name: String, value: float):
	if not stats.has(stat_name):
		push_warning("hud.gd: unknown stat '" + stat_name + "'")
		return
	var v = clampf(value, 0.0, stat_max)
	stats[stat_name] = v

	if stat_tweens.has(stat_name) and stat_tweens[stat_name].is_valid():
		stat_tweens[stat_name].kill()
	var tw = create_tween()
	tw.tween_property(stat_bars[stat_name], "value", v, 0.25)
	stat_tweens[stat_name] = tw

	_update_stat_color(stat_name)
	_update_effects()

	stat_changed.emit(stat_name, v)
	if v <= 0.0:
		stat_empty.emit(stat_name)


func change_stat(stat_name: String, amount: float):
	if stats.has(stat_name):
		set_stat(stat_name, stats[stat_name] + amount)
	else:
		push_warning("hud.gd: unknown stat '" + stat_name + "'")


func get_stat(stat_name: String) -> float:
	return stats.get(stat_name, 0.0)


func _update_money_label():
	money_label.text = money_prefix + str(money) + money_suffix


func set_money(amount: int):
	money = amount
	_update_money_label()
	money_changed.emit(money)
	_relayout_soon()


func add_money(amount: int):
	set_money(money + amount)


func get_money() -> int:
	return money


# ====================== OBJECTIVE ======================
func _build_objective():
	objective_panel = _make_panel(objective_picture, objective_design_1 != null or objective_design_2 != null)

	var col = VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", 2)
	objective_panel.add_child(col)

	var t = _make_label(objective_title_color, font_size - 2)
	t.text = objective_title
	col.add_child(t)

	objective_label = _make_label(text_color, font_size)
	objective_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	objective_label.custom_minimum_size.x = objective_width
	col.add_child(objective_label)

	_add_designs(objective_panel, objective_design_1, objective_design_1_size, objective_design_1_offset, objective_design_2, objective_design_2_size, objective_design_2_offset, panel_padding)
	_update_objective()


func _update_objective():
	objective_label.text = objective
	objective_panel.visible = show_objective and objective != ""


func set_objective(text: String):
	objective = text
	_update_objective()
	objective_changed.emit(text)
	_relayout_soon()


func clear_objective():
	set_objective("")


# ====================== INVENTORY ======================
func _build_inventory():
	inventory_panel = _make_panel(inventory_picture, inventory_design_1 != null or inventory_design_2 != null)

	var row = HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", slot_spacing)
	inventory_panel.add_child(row)

	for i in inventory_slots:
		var slot = PanelContainer.new()
		slot.custom_minimum_size = Vector2(slot_size, slot_size)
		slot.mouse_filter = Control.MOUSE_FILTER_STOP
		slot.add_theme_stylebox_override("panel", _slot_style())
		slot.gui_input.connect(_on_slot_input.bind(i))
		row.add_child(slot)

		var icon = TextureRect.new()
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		slot.add_child(icon)

		var lbl = _make_label(text_color, font_size - 4)
		lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		slot.add_child(lbl)

		_add_designs(slot, slot_design_1, slot_design_1_size, slot_design_1_offset, slot_design_2, slot_design_2_size, slot_design_2_offset, 4.0)
		slots.append({"slot": slot, "icon": icon, "label": lbl})

	_add_designs(inventory_panel, inventory_design_1, inventory_design_1_size, inventory_design_1_offset, inventory_design_2, inventory_design_2_size, inventory_design_2_offset, panel_padding)
	inventory_panel.visible = show_inventory
	_refresh_inventory()


func _refresh_inventory():
	for i in slots.size():
		var s = slots[i]
		if i < items.size():
			var it = items[i]
			s["icon"].texture = it["icon"]
			s["label"].text = it["name"] if it["icon"] == null else ""
			s["slot"].tooltip_text = it["name"]
			s["slot"].mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		else:
			s["icon"].texture = null
			s["label"].text = ""
			s["slot"].tooltip_text = ""
			s["slot"].mouse_default_cursor_shape = Control.CURSOR_ARROW


func _on_slot_input(event: InputEvent, index: int):
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		open_item(index)


# item_id: a short id like "old_key". icon: your picture. item_name: the name you see.
# info: the text you read when you open the item.
func add_item(item_id: String, icon: Texture2D = null, item_name: String = "", info: String = "") -> bool:
	if has_item(item_id) or items.size() >= inventory_slots:
		return false
	items.append({
		"id": item_id,
		"name": item_name if item_name != "" else item_id,
		"icon": icon,
		"info": info,
	})
	_refresh_inventory()
	item_added.emit(item_id)
	return true


func remove_item(item_id: String) -> bool:
	for i in items.size():
		if items[i]["id"] == item_id:
			if popup_open:
				close_item()
			items.remove_at(i)
			_refresh_inventory()
			item_removed.emit(item_id)
			return true
	return false


func has_item(item_id: String) -> bool:
	for it in items:
		if it["id"] == item_id:
			return true
	return false


func get_items() -> Array:
	var ids: Array = []
	for it in items:
		ids.append(it["id"])
	return ids


func is_inventory_full() -> bool:
	return items.size() >= inventory_slots


# ====================== ITEM WINDOW ======================
func _build_popup():
	# dark layer behind the window. A click on it closes the window.
	popup_backdrop = ColorRect.new()
	popup_backdrop.color = popup_dim_color
	popup_backdrop.mouse_filter = Control.MOUSE_FILTER_STOP
	popup_backdrop.visible = false
	layer.add_child(popup_backdrop)
	popup_backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	popup_backdrop.gui_input.connect(_on_backdrop_input)

	popup_panel = _make_panel(popup_picture, popup_design_1 != null or popup_design_2 != null)
	popup_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	popup_panel.visible = false

	var col = VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", 10)
	popup_panel.add_child(col)

	var top = HBoxContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_theme_constant_override("separation", 8)
	col.add_child(top)

	popup_name = _make_label(popup_title_color, font_size + 4)
	popup_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	popup_name.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	top.add_child(popup_name)

	var close = Button.new()
	close.focus_mode = Control.FOCUS_NONE
	close.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	close.add_theme_color_override("font_color", text_color)
	if font:
		close.add_theme_font_override("font", font)
	if popup_close_picture != null:
		var n = StyleBoxTexture.new()
		n.texture = popup_close_picture
		var h = n.duplicate()
		h.modulate_color = Color(1.25, 1.25, 1.25)
		var p = n.duplicate()
		p.modulate_color = Color(0.8, 0.8, 0.8)
		close.add_theme_stylebox_override("normal", n)
		close.add_theme_stylebox_override("hover", h)
		close.add_theme_stylebox_override("pressed", p)
		close.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
		close.custom_minimum_size = Vector2(32, 32)
	else:
		close.text = "X"
	close.pressed.connect(close_item)
	top.add_child(close)

	popup_icon = TextureRect.new()
	popup_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	popup_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	popup_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	popup_icon.custom_minimum_size = Vector2(popup_icon_size, popup_icon_size)
	popup_icon.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	col.add_child(popup_icon)

	var line = ColorRect.new()
	line.color = Color(1, 1, 1, 0.1)
	line.custom_minimum_size.y = 1
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(line)

	popup_info = _make_label(text_color, font_size)
	popup_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	popup_info.custom_minimum_size.x = popup_width
	col.add_child(popup_info)

	_add_designs(popup_panel, popup_design_1, popup_design_1_size, popup_design_1_offset, popup_design_2, popup_design_2_size, popup_design_2_offset, panel_padding)


func open_item(index: int):
	if popup_open or index < 0 or index >= items.size():
		return
	if get_tree().has_group("note_open"):
		return    # a note or the phone is already open
	popup_open = true
	add_to_group("note_open")    # stops hovering over objects and pauses the clock

	var it = items[index]
	popup_name.text = it["name"]
	popup_icon.texture = it["icon"]
	popup_icon.visible = it["icon"] != null
	popup_info.text = it["info"] if it["info"] != "" else popup_empty_text

	popup_panel.modulate.a = 0.0
	popup_panel.visible = true
	popup_backdrop.visible = true
	item_opened.emit(it["id"])

	await get_tree().process_frame    # wait so the window knows its size
	if not popup_open:
		return
	_layout()
	if popup_tween != null and popup_tween.is_valid():
		popup_tween.kill()
	popup_tween = create_tween()
	popup_tween.tween_property(popup_panel, "modulate:a", 1.0, 0.15)


func close_item():
	if not popup_open:
		return
	popup_open = false
	remove_from_group("note_open")
	if popup_tween != null and popup_tween.is_valid():
		popup_tween.kill()
	popup_panel.visible = false
	popup_backdrop.visible = false


func _on_backdrop_input(event: InputEvent):
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		close_item()


# ====================== MESSAGES (whispers) ======================
func _build_message():
	message_label = _make_label(message_color, message_font_size)
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	message_label.custom_minimum_size.x = message_width
	message_label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.9))
	message_label.add_theme_constant_override("shadow_offset_x", 2)
	message_label.add_theme_constant_override("shadow_offset_y", 2)
	message_label.modulate.a = 0.0
	layer.add_child(message_label)


# fades a short line in slowly, keeps it, then fades it out
func show_message(text: String, seconds: float = 3.0):
	message_label.text = text
	_relayout_soon()
	if message_tween != null and message_tween.is_valid():
		message_tween.kill()
	message_label.modulate.a = 0.0
	message_tween = create_tween()
	message_tween.tween_property(message_label, "modulate:a", 1.0, 0.8)
	message_tween.tween_interval(seconds)
	message_tween.tween_property(message_label, "modulate:a", 0.0, 1.5)


# ====================== STORY FLAGS ======================
func set_flag(flag_name: String, value = true):
	flags[flag_name] = value
	flag_changed.emit(flag_name, value)


func get_flag(flag_name: String, default_value = false):
	return flags.get(flag_name, default_value)


# ====================== SHOW / HIDE ======================
func show_hud(on: bool):
	layer.visible = on


# ====================== LAYOUT ======================
func _relayout_soon():
	_layout.call_deferred()
	await get_tree().process_frame
	_layout()


func _layout():
	if layer == null:
		return
	var vp = get_viewport().get_visible_rect().size
	_place(stats_panel, vp, Vector2(1, 0))        # top right
	_place(objective_panel, vp, Vector2(0, 1))    # bottom left
	_place(inventory_panel, vp, Vector2(0.5, 1))  # bottom center

	if popup_panel != null:
		popup_panel.reset_size()
		popup_panel.position = (vp - popup_panel.size) / 2.0    # center of the screen

	if message_label != null:
		message_label.reset_size()
		var inv_h = inventory_panel.size.y if inventory_panel.visible else 0.0
		message_label.position = Vector2(
			(vp.x - message_label.size.x) / 2.0,
			vp.y - margin.y - inv_h - 24.0 - message_label.size.y)


func _place(p: Control, vp: Vector2, a: Vector2):
	if p == null:
		return
	p.reset_size()
	p.position = Vector2(
		lerpf(margin.x, vp.x - p.size.x - margin.x, a.x),
		lerpf(margin.y, vp.y - p.size.y - margin.y, a.y))


# ====================== INPUT AND TEST KEYS ======================
func _input(event):
	if popup_open and event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		close_item()
		get_viewport().set_input_as_handled()
		return

	if not test_keys:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_1:
				change_stat("Sanity", -15)
			KEY_2:
				change_stat("Suspicion", 15)
			KEY_3:
				show_message("Test message.")
			KEY_4:
				var n = items.size() + 1
				add_item("test_item_" + str(n), null, "Item " + str(n), "This is the information about item " + str(n) + ". You can write a long text here.")
			KEY_5:
				set_objective("Test objective.")
