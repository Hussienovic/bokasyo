extends Node2D

@export var room_name := "Room"
@export var icon: Texture2D          # icon shown in the top bar
@export var background: Sprite2D     # the room picture (if empty, it looks for a child named "Room")

@export_group("Black and White")
@export var bw_enabled := true
@export_range(0.0, 1.0) var bw_strength := 1.0     # 1 = full black and white, 0 = original colors
@export_range(0.0, 2.0) var bw_brightness := 1.0
@export_range(0.0, 2.0) var bw_contrast := 1.0

const BW_SHADER := """
shader_type canvas_item;

uniform float strength : hint_range(0.0, 1.0) = 1.0;
uniform float brightness : hint_range(0.0, 2.0) = 1.0;
uniform float contrast : hint_range(0.0, 2.0) = 1.0;

void fragment() {
    vec4 c = texture(TEXTURE, UV);
    float g = dot(c.rgb, vec3(0.299, 0.587, 0.114));
    vec3 col = mix(c.rgb, vec3(g), strength);
    col = (col - vec3(0.5)) * contrast + vec3(0.5);
    col *= brightness;
    COLOR = vec4(col, c.a);
}
"""


func _ready():
	if background == null and self is Sprite2D:
		background = self as Sprite2D      # the room node itself is the picture
	if background == null:
		background = get_node_or_null("Room") as Sprite2D
	if background == null:
		for c in get_children():
			if c is Sprite2D:
				background = c
				break
	if background == null:
		push_warning("room.gd: no background sprite found in " + name)
		return

	if bw_enabled:
		var shader = Shader.new()
		shader.code = BW_SHADER
		var mat = ShaderMaterial.new()
		mat.shader = shader
		mat.set_shader_parameter("strength", bw_strength)
		mat.set_shader_parameter("brightness", bw_brightness)
		mat.set_shader_parameter("contrast", bw_contrast)
		background.material = mat
