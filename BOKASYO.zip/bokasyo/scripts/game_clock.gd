extends Node

signal minute_changed(day, hour, minute)
signal hour_changed(day, hour)
signal day_changed(day)
signal event_triggered(event_name)

# ---------------- TIME ----------------
@export_group("Time")
@export var running := true
@export var game_minutes_per_second := 1.0   # 1 = one game minute per real second (a day lasts 24 min)
@export var start_day := 1
@export_range(0, 23) var start_hour := 8
@export_range(0, 59) var start_minute := 0
@export var pause_when_note_open := true

# ---------------- DISPLAY ----------------
@export_group("Display")
@export var show_clock := true
@export var margin := Vector2(15, 15)         # distance from the top-left corner
@export var font: Font
@export var show_analog := true               # the clock face with hands
@export var show_digital := false             # small digital text under the face
@export var use_24_hour := true               # digital text only
@export var digital_font_size := 24
@export var digital_color := Color.WHITE
@export var show_day := true
@export var day_text := "Day"
@export var day_font_size := 16
@export var day_color := Color(0.85, 0.85, 0.85)

# ---------------- ANALOG CLOCK ----------------
@export_group("Analog Clock")
@export var clock_size := 140.0
@export var smooth_hands := true             # hands move smoothly instead of jumping each minute
@export var show_ticks := true
@export var show_numbers := true
@export var numbers_all := true              # off = only 12, 3, 6, 9
@export var number_font_size := 18
@export var face_color := Color(0.96, 0.93, 0.85)
@export var face_border_color := Color(0.2, 0.12, 0.05)
@export var face_border_width := 6.0
@export var tick_color := Color(0.2, 0.12, 0.05)
@export var number_color := Color(0.2, 0.12, 0.05)
@export var hour_hand_color := Color(0.1, 0.07, 0.03)
@export var minute_hand_color := Color(0.1, 0.07, 0.03)
@export var hour_hand_width := 6.0
@export var minute_hand_width := 4.0
@export_range(0.1, 1.0) var hour_hand_length := 0.5
@export_range(0.1, 1.0) var minute_hand_length := 0.78
@export var center_dot_size := 6.0

# ---------------- YOUR OWN PICTURES (optional) ----------------
# All three pictures must be square and the SAME canvas size.
# The hands must be drawn pointing straight up (12 o'clock), and they turn around the middle of the picture.
@export_group("Custom Pictures (optional)")
@export var face_picture: Texture2D
@export var hour_hand_picture: Texture2D
@export var minute_hand_picture: Texture2D

# ---------------- BOX DESIGN ----------------
@export_group("Box Design")
@export var show_box := false                # box behind the clock
@export var box_color := Color(0.05, 0.05, 0.08, 0.85)
@export var box_border_color := Color(0.4, 0.4, 0.45)
@export var box_border_width := 2
@export var box_corner_radius := 10
@export var box_padding := 10
@export var box_picture: Texture2D           # optional picture instead of the plain box
@export var box_picture_margin := 16         # edge size kept when the picture stretches

var total := 0.0          # game minutes since Day 1, 00:00
var events: Array = []    # scheduled events
var last_drawn := -1.0

var layer: CanvasLayer
var panel: PanelContainer
var face: Control
var time_label: Label
var day_label: Label


func _ready():
	add_to_group("game_clock")
	total = float((start_day - 1) * 1440 + start_hour * 60 + start_minute)
	_build_ui()
	_update_label()


# ====================== UI ======================
func _build_ui():
	layer = CanvasLayer.new()
	layer.layer = 60
	add_child(layer)

	panel = PanelContainer.new()
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.visible = show_clock
	layer.add_child(panel)
	panel.position = margin

	if not show_box:
		var se = StyleBoxEmpty.new()
		panel.add_theme_stylebox_override("panel", se)
	elif box_picture != null:
		var sbt = StyleBoxTexture.new()
		sbt.texture = box_picture
		sbt.set_texture_margin_all(box_picture_margin)
		sbt.set_content_margin_all(box_padding)
		panel.add_theme_stylebox_override("panel", sbt)
	else:
		var sb = StyleBoxFlat.new()
		sb.bg_color = box_color
		sb.border_color = box_border_color
		sb.set_border_width_all(box_border_width)
		sb.set_corner_radius_all(box_corner_radius)
		sb.set_content_margin_all(box_padding)
		panel.add_theme_stylebox_override("panel", sb)

	var col = VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", 4)
	panel.add_child(col)

	face = Control.new()
	face.custom_minimum_size = Vector2(clock_size, clock_size)
	face.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	face.mouse_filter = Control.MOUSE_FILTER_IGNORE
	face.visible = show_analog
	face.draw.connect(_draw_face)
	col.add_child(face)

	time_label = _make_label(digital_color, digital_font_size)
	time_label.visible = show_digital
	col.add_child(time_label)

	day_label = _make_label(day_color, day_font_size)
	col.add_child(day_label)


func _make_label(color: Color, size: int) -> Label:
	var l = Label.new()
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_color_override("font_color", color)
	l.add_theme_font_size_override("font_size", size)
	if font:
		l.add_theme_font_override("font", font)
	return l


func _update_label():
	if time_label == null:
		return
	time_label.text = get_time_string()
	day_label.text = "%s %d" % [day_text, get_day()]
	day_label.visible = show_day


# ====================== DRAWING THE CLOCK ======================
func _dir(angle: float) -> Vector2:
	# angle 0 = pointing up (12 o'clock), turning clockwise
	return Vector2(sin(angle), -cos(angle))


func _draw_face():
	var s = clock_size
	var c = Vector2(s, s) / 2.0
	var radius = s / 2.0 - face_border_width

	# ----- face -----
	if face_picture != null:
		face.draw_texture_rect(face_picture, Rect2(Vector2.ZERO, Vector2(s, s)), false)
	else:
		face.draw_circle(c, radius, face_color)
		face.draw_arc(c, radius, 0.0, TAU, 96, face_border_color, face_border_width, true)

		if show_ticks:
			for i in 60:
				var d = _dir(float(i) / 60.0 * TAU)
				var big = (i % 5 == 0)
				var tick_len = radius * (0.12 if big else 0.06)
				var tick_w = 3.0 if big else 1.5
				face.draw_line(c + d * (radius - tick_len - 3.0), c + d * (radius - 3.0), tick_color, tick_w, true)

		if show_numbers:
			var f: Font = font if font else ThemeDB.fallback_font
			var nr = radius - radius * 0.12 - number_font_size * 0.8
			for n in range(1, 13):
				if not numbers_all and n % 3 != 0:
					continue
				var p = c + _dir(float(n) / 12.0 * TAU) * nr
				var txt = str(n)
				var w = f.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, number_font_size).x
				var base = f.get_ascent(number_font_size) - f.get_height(number_font_size) / 2.0
				face.draw_string(f, p + Vector2(-w / 2.0, base), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, number_font_size, number_color)

	# ----- hand angles -----
	var t = total if smooth_hands else floorf(total)
	var a_min = fmod(t, 60.0) / 60.0 * TAU
	var a_hour = fmod(t, 720.0) / 720.0 * TAU

	# ----- hands -----
	if hour_hand_picture != null:
		_draw_picture_hand(hour_hand_picture, a_hour, s, c)
	else:
		var dh = _dir(a_hour)
		face.draw_line(c - dh * radius * 0.1, c + dh * radius * hour_hand_length, hour_hand_color, hour_hand_width, true)

	if minute_hand_picture != null:
		_draw_picture_hand(minute_hand_picture, a_min, s, c)
	else:
		var dm = _dir(a_min)
		face.draw_line(c - dm * radius * 0.12, c + dm * radius * minute_hand_length, minute_hand_color, minute_hand_width, true)

	if hour_hand_picture == null or minute_hand_picture == null:
		face.draw_circle(c, center_dot_size, minute_hand_color)


func _draw_picture_hand(tex: Texture2D, angle: float, s: float, c: Vector2):
	var sc = Vector2(s / tex.get_width(), s / tex.get_height())
	face.draw_set_transform(c, angle, sc)
	face.draw_texture(tex, -tex.get_size() / 2.0)
	face.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# ====================== TIME LOOP ======================
func _process(delta):
	# redraw the clock only when the time changed
	if face != null and show_analog and total != last_drawn:
		last_drawn = total
		face.queue_redraw()

	if not running:
		return
	if pause_when_note_open and get_tree().has_group("note_open"):
		return

	var before = int(total)
	total += delta * game_minutes_per_second
	var after = int(total)
	if after != before:
		for t in range(before + 1, after + 1):
			_tick(t)


func _tick(t: int):
	_update_label()
	minute_changed.emit(_day(t), _hour(t), _minute(t))
	if _minute(t) == 0:
		hour_changed.emit(_day(t), _hour(t))
		if _hour(t) == 0:
			day_changed.emit(_day(t))

	# scheduled story events
	for e in events.duplicate():
		if e["time"] <= t:
			events.erase(e)
			event_triggered.emit(e["name"])


# ====================== HELPERS ======================
func _day(t: int) -> int:
	return floori(t / 1440.0) + 1

func _hour(t: int) -> int:
	return floori((t % 1440) / 60.0)

func _minute(t: int) -> int:
	return t % 60


# ====================== USE THESE FROM YOUR STORY SCRIPTS ======================
func get_day() -> int:
	return _day(int(total))

func get_hour() -> int:
	return _hour(int(total))

func get_minute() -> int:
	return _minute(int(total))

func get_total_minutes() -> int:
	return int(total)

func get_time_string() -> String:
	var h = get_hour()
	var m = get_minute()
	if use_24_hour:
		return "%02d:%02d" % [h, m]
	var suffix = "AM" if h < 12 else "PM"
	var h12 = h % 12
	if h12 == 0:
		h12 = 12
	return "%d:%02d %s" % [h12, m, suffix]

# true if the time is between two hours, also works across midnight (for example 22 to 6)
func is_time_between(from_hour: int, to_hour: int) -> bool:
	var h = get_hour()
	if from_hour <= to_hour:
		return h >= from_hour and h < to_hour
	return h >= from_hour or h < to_hour

func set_time(day: int, hour: int, minute: int):
	total = float((day - 1) * 1440 + hour * 60 + minute)
	_update_label()

func skip_minutes(minutes: int):
	var before = int(total)
	total += minutes
	for t in range(before + 1, int(total) + 1):
		_tick(t)

func pause_clock():
	running = false

func resume_clock():
	running = true

# calls event_triggered(event_name) once when that time is reached
func schedule(event_name: String, day: int, hour: int, minute: int):
	events.append({"name": event_name, "time": (day - 1) * 1440 + hour * 60 + minute})
