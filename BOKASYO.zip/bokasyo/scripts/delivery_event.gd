extends Node
# TEMPORARY EVENT: the delivery guy at the outside door.
# Click the door -> it opens -> talk to the delivery guy (with choices).
# Put this node inside the "Outside Door" room and fill the 3 slots in the Inspector.

@export var door: Sprite2D          # the closed door (the clickable one)
@export var door_open: Sprite2D     # picture of the open door
@export var guy: Sprite2D           # the delivery guy

const GUY := "Delivery guy"
const YOU := "You"

var box                              # dialogue box (scripts/dialogue_box.gd)
var state := 0                       # 0 = waiting, 1 = talking, 2 = finished
var bob_tween: Tween


func _ready():
	box = preload("res://scripts/dialogue_box.gd").new()
	add_child(box)

	guy.visible = false
	door_open.visible = false
	door.connect("clicked", _on_door_clicked)

	# small objective after the game has started
	await get_tree().create_timer(0.8).timeout
	if state == 0:
		var h = _hud()
		if h != null:
			h.set_objective("Someone is knocking at the front door.")


func _hud():
	return get_tree().get_first_node_in_group("game_hud")


func _stat(stat_name: String, amount: float):
	var h = _hud()
	if h != null:
		h.change_stat(stat_name, amount)


func _flag(flag_name: String):
	var h = _hud()
	if h != null:
		h.set_flag(flag_name, true)


func _message(text: String):
	var h = _hud()
	if h != null:
		h.show_message(text)


# ====================== DOOR ======================
func _on_door_clicked(_obj):
	if state == 1:
		return
	if state == 2:
		_message("Nobody is out there anymore.")
		return
	_run_event()


func _open_door():
	door.visible = false
	door_open.visible = true
	guy.visible = true
	guy.modulate.a = 0.0
	var t = create_tween()
	t.tween_property(guy, "modulate:a", 1.0, 0.7)
	await t.finished
	# he sways a little, like he is breathing
	var y0 = guy.position.y
	bob_tween = create_tween().set_loops()
	bob_tween.tween_property(guy, "position:y", y0 - 3.0, 1.6).set_trans(Tween.TRANS_SINE)
	bob_tween.tween_property(guy, "position:y", y0, 1.6).set_trans(Tween.TRANS_SINE)


func _guy_leaves():
	if bob_tween != null and bob_tween.is_valid():
		bob_tween.kill()
	var t = create_tween()
	t.tween_property(guy, "modulate:a", 0.0, 0.9)
	await t.finished
	guy.visible = false
	door_open.visible = false
	door.visible = true
	door.set("info", "The front door. Nobody is out there.")


# ====================== THE CONVERSATION ======================
func _run_event():
	state = 1
	var h = _hud()
	if h != null:
		h.clear_objective()

	await box.say("", "You open the door.")
	box.close()
	await _open_door()

	await box.say(GUY, "WESH FRERO! Ca va ou quoi?")
	await box.say(GUY, "Delivery, frero. Package for this apartment. Ba oui, for you.")
	await box.say("", "His face is just smoke. It moves when he talks, like it is chewing the words.")

	var asked := []
	var asked_human := false
	var leave := false
	var took := false

	while not leave:
		# after two questions he asks his own question
		if asked.size() >= 2 and not asked_human:
			asked_human = true
			await _human_question()
			continue

		var ids := []
		var labels := []
		if not asked.has("who"):
			ids.append("who")
			labels.append("Who are you?")
		if not asked.has("order"):
			ids.append("order")
			labels.append("I didn't order anything.")
		if not asked.has("neighbors"):
			ids.append("neighbors")
			labels.append("Do you deliver to my neighbors too?")
		ids.append("take")
		labels.append("Take the package.")
		ids.append("close")
		labels.append("(Close the door.)")

		var pick: int = await box.choose(labels)
		var id: String = ids[pick]

		match id:
			"who":
				asked.append("who")
				await box.say(YOU, "Who are you?")
				await box.say(GUY, "Me? Nobody, frero. The delivery guy. I bring, I leave, c'est tout.")
				await box.say(GUY, "And don't stare at my face, hein. It's the smoke. Occupational hazard. Chill.")
			"order":
				asked.append("order")
				await box.say(YOU, "I didn't order anything.")
				await box.say(GUY, "Everybody says that, frero. Look, no name on the box. Just the address.")
				await box.say(GUY, "Apartment 7. That's you, no? Unless you're not you. Hahaha, I'm joking, relax.")
			"neighbors":
				asked.append("neighbors")
				_stat("Sanity", -5)
				_flag("asked_delivery_guy_about_neighbors")
				await box.say(YOU, "Do you deliver to my neighbors too?")
				await box.say(GUY, "Les voisins...")
				await box.say("", "The smoke stops moving for a second.")
				await box.say(GUY, "Frero, I come here every week. I knock on every door. Lights on, music on, TV on...")
				await box.say(GUY, "...and nobody opens. Nobody. Except you.")
				await box.say(GUY, "Anyway! Not my problem, wallah. I just deliver.")
			"take":
				if not asked_human:
					asked_human = true
					await _human_question()
				leave = true
				took = true
				await _take_package()
			"close":
				leave = true
				_stat("Suspicion", 5)
				await box.say(YOU, "Sorry, wrong time.")
				await box.say(GUY, "Eh! Rude, frero! But okay, okay. I'm not offended. Much.")
				await box.say(GUY, "The package stays on the floor. It will wait for you. They always do.")

	box.close()
	await _guy_leaves()
	await get_tree().create_timer(0.4).timeout
	await box.say("", "The stairs are silent. You never heard him walk away.")
	box.close()
	_flag("met_delivery_guy")
	state = 2
	var h2 = _hud()
	if h2 != null and took:
		h2.set_objective("Find out what is inside the package.")


# the "are you human?" question (inspired by the 'I'm not human' idea, own version)
func _human_question():
	await box.say(GUY, "Eh, wait. One question, frero. Protocol, you know. They told me to ask everybody.")
	await box.say(GUY, "You are... human? Like, for real?")

	var pick: int = await box.choose([
		"Yes. Obviously.",
		"No. I'm not human.",
		"What kind of question is that?",
		"Do I look like a ghost to you?",
	])

	match pick:
		0:
			await box.say(YOU, "Yes. Obviously.")
			await box.say(GUY, "Mmh. That's what the last one said too, frero.")
			_stat("Sanity", -5)
			_flag("told_guy_human")
		1:
			await box.say(YOU, "No. I'm not human.")
			await box.say(GUY, "HAHAHA! Okay okay okay! I respect it, frero. Honesty first.")
			await box.say(GUY, "Then you don't need to sign. Nice, we are good.")
			_stat("Suspicion", 10)
			_flag("told_guy_not_human")
		2:
			await box.say(YOU, "What kind of question is that?")
			await box.say(GUY, "Easy, easy! It's the new rule. I ask, you answer, everybody goes home.")
			await box.say(GUY, "Me, I never ask who 'they' are. Healthy for the job.")
			_stat("Suspicion", 5)
		3:
			await box.say(YOU, "Do I look like a ghost to you?")
			await box.say(GUY, "Hah! Frero, between us...")
			await box.say(GUY, "In this building I can't tell who is who anymore.")
			_stat("Sanity", -5)
			_flag("joked_about_ghost")


func _take_package():
	await box.say("", "You take the package. It is lighter than it should be.")
	await box.say(GUY, "Parfait. Bon, I'm out, frero. Enjoy.")
	await box.say(GUY, "And tonight, if you hear knocking inside the wall... don't answer. Bisous.")
	_flag("has_mystery_package")
