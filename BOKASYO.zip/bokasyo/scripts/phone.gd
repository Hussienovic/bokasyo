extends Node

signal phone_opened
signal phone_closed
signal message_received(contact, text)
signal message_sent(contact, text)
signal choice_made(contact, index, text)
signal note_added(title)
signal battery_changed(value)
signal battery_dead

# ---------------- PHONE ----------------
@export_group("Phone")
@export var toggle_key: Key = KEY_P
@export var phone_size := Vector2(300, 560)
@export var phone_margin := Vector2(20, 20)
@export var slide_time := 0.3

# ---------------- LOOK ----------------
@export_group("Look")
@export var font: Font
@export var font_size := 16
@export var text_color := Color(0.82, 0.8, 0.74)
@export var dim_text_color := Color(0.5, 0.5, 0.48)
@export var accent_color := Color(0.65, 0.08, 0.08)
@export var body_color := Color(0.04, 0.04, 0.045)
@export var body_border_color := Color(0.22, 0.22, 0.24)
@export var body_border_width := 3
@export var body_corner_radius := 28
@export var screen_color := Color(0.02, 0.02, 0.025)
@export var screen_margin := 14                  # space between the phone edge and the screen
@export var frame_picture: Texture2D             # optional picture of your own phone body
@export var frame_picture_margin := 40
@export var incoming_bubble_color := Color(0.17, 0.17, 0.19)
@export var outgoing_bubble_color := Color(0.30, 0.09, 0.09)

# ---------------- PHONE BUTTON ----------------
@export_group("Phone Button")
@export var button_icon: Texture2D
@export var button_size := 56.0
@export var button_margin := Vector2(15, 15)

# ---------------- APP ICONS ----------------
@export_group("Apps")
@export var messages_icon: Texture2D
@export var notes_icon: Texture2D

# ---------------- BATTERY AND SIGNAL ----------------
@export_group("Battery and Signal")
@export var battery_enabled := true
@export var battery_start := 100.0
@export var battery_drain_per_hour := 4.0        # per game hour (needs the clock)
@export_range(0, 4) var signal_bars := 4

# ---------------- NOTIFICATIONS ----------------
@export_group("Notifications")
@export var show_toast := true
@export var notification_sound: AudioStream
@export var toast_seconds := 3.5

# ---------------- TEST ----------------
@export_group("Test")
@export var test_keys := true    # F1 to F4 try the phone. Turn off when you are done testing

var conversations := {}     # contact -> {"messages": [...], "unread": int}
var pending_choices := {}   # contact -> Array of answers
var notes: Array = []
var custom_apps: Array = []
var battery := 100.0
var is_open := false
var screen := "home"
var screen_arg = null
var clock = null

var layer: CanvasLayer
var phone_panel: PanelContainer
var status_time: Label
var status_battery: Label
var signal_rects: Array = []
var content: VBoxContainer
var phone_button: BaseButton
var phone_badge: PanelContainer
var phone_badge_label: Label
var toast_panel: PanelContainer
var toast_title: Label
var toast_text: Label
var toast_tween: Tween
var slide_tween: Tween
var player: AudioStreamPlayer


func _ready():
	add_to_group("phone")
	battery = battery_start

	layer = CanvasLayer.new()
	layer.layer = 120
	add_child(layer)

	player = AudioStreamPlayer.new()
	player.stream = notification_sound
	add_child(player)

	_build_phone()
	_build_button()
	_build_toast()
	phone_panel.visible = false

	get_viewport().size_changed.connect(_layout)
	_layout()
	await get_tree().process_frame
	_layout()

	clock = get_tree().get_first_node_in_group("game_clock")
	if clock != null:
		clock.minute_changed.connect(_on_minute)
	_update_status()


# ====================== SMALL HELPERS ======================
func _label(text: String, size: int, color: Color) -> Label:
	var l = Label.new()
	l.text = text
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if font:
		l.add_theme_font_override("font", font)
	return l


func _box(bg: Color, radius: int, border: Color = Color(0, 0, 0, 0), border_w: int = 0, margin: int = 8) -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(border_w)
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(margin)
	return s


func _style_button(b: Button, bg: Color, radius: int, border: Color = Color(0, 0, 0, 0), border_w: int = 0):
	var n = _box(bg, radius, border, border_w)
	var h = _box(bg.lightened(0.12), radius, border, border_w)
	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", h)
	b.add_theme_stylebox_override("pressed", h)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", text_color)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_font_size_override("font_size", font_size)
	if font:
		b.add_theme_font_override("font", font)
	b.focus_mode = Control.FOCUS_NONE
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND


func _inner_width() -> float:
	return phone_size.x - screen_margin * 2.0 - 20.0


func _now() -> String:
	if clock != null:
		return clock.get_time_string()
	return ""


func _short(text: String, limit: int = 40) -> String:
	if text.length() <= limit:
		return text
	return text.substr(0, limit) + "..."


func _dim_note(text: String) -> Label:
	var l = _label(text, font_size, dim_text_color)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


# ====================== BUILD THE PHONE ======================
func _build_phone():
	phone_panel = PanelContainer.new()
	phone_panel.custom_minimum_size = phone_size
	phone_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	layer.add_child(phone_panel)

	if frame_picture != null:
		var t = StyleBoxTexture.new()
		t.texture = frame_picture
		t.set_texture_margin_all(frame_picture_margin)
		t.set_content_margin_all(screen_margin)
		phone_panel.add_theme_stylebox_override("panel", t)
	else:
		var s = _box(body_color, body_corner_radius, body_border_color, body_border_width, screen_margin)
		phone_panel.add_theme_stylebox_override("panel", s)

	var screen_bg = PanelContainer.new()
	screen_bg.clip_contents = true
	screen_bg.add_theme_stylebox_override("panel", _box(screen_color, maxi(body_corner_radius - 8, 4), Color(0, 0, 0, 0), 0, 10))
	phone_panel.add_child(screen_bg)

	var col = VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	screen_bg.add_child(col)

	# status bar
	var bar = HBoxContainer.new()
	bar.add_theme_constant_override("separation", 8)
	col.add_child(bar)

	status_time = _label("", font_size - 2, dim_text_color)
	status_time.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bar.add_child(status_time)

	var sig = HBoxContainer.new()
	sig.add_theme_constant_override("separation", 2)
	bar.add_child(sig)
	for i in 4:
		var r = ColorRect.new()
		r.custom_minimum_size = Vector2(4, 4 + i * 3)
		r.size_flags_vertical = Control.SIZE_SHRINK_END
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		sig.add_child(r)
		signal_rects.append(r)

	status_battery = _label("", font_size - 2, dim_text_color)
	bar.add_child(status_battery)

	# the changing part of the screen
	content = VBoxContainer.new()
	content.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 8)
	col.add_child(content)

	# home button
	var home = Button.new()
	home.text = "Home"
	home.flat = true
	_style_button(home, Color(0, 0, 0, 0), 6)
	home.add_theme_color_override("font_color", dim_text_color)
	home.add_theme_font_size_override("font_size", font_size - 3)
	home.pressed.connect(_show.bind("home", null))
	col.add_child(home)


func _build_button():
	var b: BaseButton
	if button_icon != null:
		var tb = TextureButton.new()
		tb.texture_normal = button_icon
		tb.ignore_texture_size = true
		tb.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
		b = tb
	else:
		var bb = Button.new()
		bb.text = "Phone"
		_style_button(bb, body_color, 12, body_border_color, 2)
		bb.add_theme_font_size_override("font_size", font_size - 2)
		b = bb
	b.custom_minimum_size = Vector2(button_size, button_size)
	b.focus_mode = Control.FOCUS_NONE
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	b.pressed.connect(toggle_phone)
	layer.add_child(b)
	phone_button = b

	phone_badge = PanelContainer.new()
	phone_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	phone_badge.add_theme_stylebox_override("panel", _box(accent_color, 10, Color(0, 0, 0, 0), 0, 4))
	phone_badge.visible = false
	layer.add_child(phone_badge)
	phone_badge_label = _label("0", font_size - 4, Color.WHITE)
	phone_badge.add_child(phone_badge_label)


func _build_toast():
	toast_panel = PanelContainer.new()
	toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_panel.modulate.a = 0.0
	toast_panel.add_theme_stylebox_override("panel", _box(Color(0.05, 0.05, 0.06, 0.92), 10, body_border_color, 1, 10))
	layer.add_child(toast_panel)

	var v = VBoxContainer.new()
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_panel.add_child(v)

	toast_title = _label("", font_size - 2, accent_color)
	v.add_child(toast_title)

	toast_text = _label("", font_size, text_color)
	toast_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	toast_text.custom_minimum_size.x = 260
	v.add_child(toast_text)


# ====================== POSITION ======================
func _open_position(vp: Vector2) -> Vector2:
	return Vector2(vp.x - phone_size.x - phone_margin.x, (vp.y - phone_size.y) / 2.0)


func _layout():
	var vp = get_viewport().get_visible_rect().size
	if phone_button != null:
		phone_button.position = Vector2(vp.x - button_size - button_margin.x, vp.y - button_size - button_margin.y)
		phone_button.size = Vector2(button_size, button_size)
	if phone_badge != null and phone_button != null:
		phone_badge.position = phone_button.position + Vector2(button_size - 14, -8)
	if phone_panel != null and is_open:
		phone_panel.position = _open_position(vp)
	if toast_panel != null:
		toast_panel.reset_size()
		toast_panel.position = Vector2((vp.x - toast_panel.size.x) / 2.0, 90.0)


# ====================== OPEN / CLOSE ======================
func toggle_phone():
	if is_open:
		close_phone()
	else:
		open_phone()


func open_phone():
	if is_open:
		return
	if get_tree().has_group("note_open"):
		return    # a note is open, do not open the phone on top of it
	is_open = true
	add_to_group("note_open")    # stops hovering over objects and pauses the clock while the phone is open

	var vp = get_viewport().get_visible_rect().size
	var target = _open_position(vp)
	phone_panel.visible = true
	phone_panel.position = Vector2(target.x, vp.y)
	_show(screen, screen_arg)
	_update_status()

	if slide_tween != null and slide_tween.is_valid():
		slide_tween.kill()
	slide_tween = create_tween()
	slide_tween.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	slide_tween.tween_property(phone_panel, "position:y", target.y, slide_time)
	phone_opened.emit()


func close_phone():
	if not is_open:
		return
	is_open = false
	remove_from_group("note_open")

	var vp = get_viewport().get_visible_rect().size
	if slide_tween != null and slide_tween.is_valid():
		slide_tween.kill()
	slide_tween = create_tween()
	slide_tween.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
	slide_tween.tween_property(phone_panel, "position:y", vp.y, slide_time)
	slide_tween.tween_callback(func(): phone_panel.visible = false)
	_update_badges()
	phone_closed.emit()


# ====================== SCREENS ======================
func _clear_content():
	for c in content.get_children():
		content.remove_child(c)
		c.queue_free()


func _show(screen_name: String, arg = null):
	screen = screen_name
	screen_arg = arg
	_clear_content()
	if battery_enabled and battery <= 0.0:
		_build_dead()
		_update_badges()
		return
	match screen_name:
		"home":
			_build_home()
		"messages":
			_build_messages()
		"conversation":
			_build_conversation(arg)
		"notes":
			_build_notes()
		"note":
			_build_note(arg)
	_update_badges()


func _header(title: String, back_to: String, back_arg = null):
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	content.add_child(row)

	if back_to != "":
		var back = Button.new()
		back.text = "<"
		_style_button(back, Color(0.08, 0.08, 0.09), 6)
		back.pressed.connect(_show.bind(back_to, back_arg))
		row.add_child(back)

	var t = _label(title, font_size + 2, text_color)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.clip_text = true
	t.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	row.add_child(t)

	var line = ColorRect.new()
	line.color = Color(1, 1, 1, 0.08)
	line.custom_minimum_size.y = 1
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.add_child(line)


func _make_scroll() -> ScrollContainer:
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	content.add_child(scroll)
	return scroll


func _scroll_bottom(scroll: ScrollContainer):
	await get_tree().process_frame
	await get_tree().process_frame
	if is_instance_valid(scroll):
		scroll.scroll_vertical = int(scroll.get_v_scroll_bar().max_value)


# ----- home -----
func _build_home():
	var spacer = Control.new()
	spacer.custom_minimum_size.y = 20
	content.add_child(spacer)

	var grid = GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 14)
	grid.add_theme_constant_override("v_separation", 18)
	content.add_child(grid)

	_add_app(grid, "Messages", messages_icon, func(): _show("messages"), _total_unread())
	_add_app(grid, "Notes", notes_icon, func(): _show("notes"), 0)
	for a in custom_apps:
		_add_app(grid, a["name"], a["icon"], a["on_open"], 0)


func _add_app(grid: GridContainer, app_name: String, icon: Texture2D, on_open: Callable, badge: int):
	var cell = VBoxContainer.new()
	cell.add_theme_constant_override("separation", 4)
	grid.add_child(cell)

	var holder = Control.new()
	holder.custom_minimum_size = Vector2(64, 64)
	holder.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	cell.add_child(holder)

	var b = Button.new()
	_style_button(b, Color(0.1, 0.1, 0.12), 14)
	if icon != null:
		b.icon = icon
		b.expand_icon = true
	else:
		b.text = app_name.substr(0, 1).to_upper()
		b.add_theme_font_size_override("font_size", 26)
	b.pressed.connect(on_open)
	holder.add_child(b)
	b.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	if badge > 0:
		var bp = PanelContainer.new()
		bp.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bp.add_theme_stylebox_override("panel", _box(accent_color, 10, Color(0, 0, 0, 0), 0, 3))
		bp.add_child(_label(str(badge), font_size - 4, Color.WHITE))
		holder.add_child(bp)
		bp.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)

	var nl = _label(app_name, font_size - 3, text_color)
	nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cell.add_child(nl)


# ----- messages list -----
func _build_messages():
	_header("Messages", "home")
	if conversations.is_empty():
		content.add_child(_dim_note("No messages."))
		return

	var scroll = _make_scroll()
	var list = VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 6)
	scroll.add_child(list)

	var contacts = conversations.keys()
	contacts.reverse()    # newest first
	for contact in contacts:
		var conv = conversations[contact]
		var last = ""
		if conv["messages"].size() > 0:
			last = conv["messages"][-1]["text"]
		var unread = conv["unread"]

		var b = Button.new()
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.clip_text = true
		var suffix = ("  (" + str(unread) + ")") if unread > 0 else ""
		b.text = contact + suffix + "\n" + _short(last)
		_style_button(b, Color(0.09, 0.09, 0.1), 8)
		if unread > 0:
			b.add_theme_color_override("font_color", accent_color)
		b.pressed.connect(_show.bind("conversation", contact))
		list.add_child(b)


# ----- one conversation -----
func _make_bubble(m: Dictionary) -> Control:
	var from_me: bool = m["from_me"]
	var row = HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_END if from_me else BoxContainer.ALIGNMENT_BEGIN

	var bubble = PanelContainer.new()
	bubble.add_theme_stylebox_override("panel", _box(outgoing_bubble_color if from_me else incoming_bubble_color, 12))
	row.add_child(bubble)

	var v = VBoxContainer.new()
	v.add_theme_constant_override("separation", 2)
	bubble.add_child(v)

	var f: Font = font if font else ThemeDB.fallback_font
	var tw = f.get_string_size(m["text"], HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x + 4.0
	var lbl = _label(m["text"], font_size, text_color)
	lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lbl.custom_minimum_size.x = minf(tw, _inner_width() * 0.75)
	v.add_child(lbl)

	if m["time"] != "":
		var tl = _label(m["time"], font_size - 5, dim_text_color)
		tl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		v.add_child(tl)
	return row


func _build_conversation(contact):
	if not conversations.has(contact):
		conversations[contact] = {"messages": [], "unread": 0}
	var conv = conversations[contact]
	conv["unread"] = 0

	_header(str(contact), "messages")

	var scroll = _make_scroll()
	var list = VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 6)
	scroll.add_child(list)

	if conv["messages"].is_empty():
		list.add_child(_dim_note("No messages yet."))
	for m in conv["messages"]:
		list.add_child(_make_bubble(m))

	# answers the player can choose
	if pending_choices.has(contact):
		var box = VBoxContainer.new()
		box.add_theme_constant_override("separation", 4)
		content.add_child(box)
		var options = pending_choices[contact]
		for i in options.size():
			var holder = PanelContainer.new()
			holder.add_theme_stylebox_override("panel", _box(Color(0.1, 0.05, 0.05), 8, Color(0.5, 0.1, 0.1), 1, 8))
			box.add_child(holder)

			var lbl = _label("> " + str(options[i]), font_size, text_color)
			lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			lbl.custom_minimum_size.x = _inner_width() - 24.0
			holder.add_child(lbl)

			var hit = Button.new()
			hit.focus_mode = Control.FOCUS_NONE
			hit.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
			hit.add_theme_stylebox_override("normal", StyleBoxEmpty.new())
			hit.add_theme_stylebox_override("hover", _box(Color(1, 1, 1, 0.06), 8))
			hit.add_theme_stylebox_override("pressed", _box(Color(1, 1, 1, 0.1), 8))
			hit.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
			hit.pressed.connect(_pick_choice.bind(contact, i))
			holder.add_child(hit)

	_scroll_bottom(scroll)


# ----- notes -----
func _build_notes():
	_header("Notes", "home")
	if notes.is_empty():
		content.add_child(_dim_note("Empty."))
		return
	var scroll = _make_scroll()
	var list = VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 6)
	scroll.add_child(list)

	for i in notes.size():
		var b = Button.new()
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.clip_text = true
		b.text = notes[i]["title"]
		_style_button(b, Color(0.09, 0.09, 0.1), 8)
		b.pressed.connect(_show.bind("note", i))
		list.add_child(b)


func _build_note(i):
	if i == null or i >= notes.size():
		_build_notes()
		return
	_header(notes[i]["title"], "notes")
	var scroll = _make_scroll()
	var lbl = _label(notes[i]["text"], font_size, text_color)
	lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lbl.custom_minimum_size.x = _inner_width()
	scroll.add_child(lbl)


# ----- dead battery -----
func _build_dead():
	var top = Control.new()
	top.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(top)
	var l = _label("Battery empty.", font_size + 2, dim_text_color)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	content.add_child(l)
	var bottom = Control.new()
	bottom.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(bottom)


# ====================== STATUS BAR AND BADGES ======================
func _total_unread() -> int:
	var total = 0
	for c in conversations:
		total += conversations[c]["unread"]
	return total


func _update_badges():
	if phone_badge == null:
		return
	var total = _total_unread()
	phone_badge.visible = total > 0 and not is_open
	phone_badge_label.text = str(total)


func _update_status():
	if status_time == null:
		return
	status_time.text = clock.get_time_string() if clock != null else "--:--"
	status_battery.text = (str(int(battery)) + "%") if battery_enabled else ""
	status_battery.add_theme_color_override("font_color", accent_color if battery <= 15.0 else dim_text_color)
	for i in signal_rects.size():
		signal_rects[i].color = text_color if i < signal_bars else Color(0.25, 0.25, 0.25)
	_update_badges()


func _on_minute(_day, _hour, _minute):
	if battery_enabled and battery > 0.0:
		battery = maxf(0.0, battery - battery_drain_per_hour / 60.0)
		battery_changed.emit(battery)
		if battery <= 0.0:
			battery_dead.emit()
			if is_open:
				_show(screen, screen_arg)
	_update_status()


# ====================== NOTIFICATION POP-UP ======================
func _show_toast(title: String, text: String):
	if not show_toast:
		return
	toast_title.text = title
	toast_text.text = _short(text, 80)
	_layout()
	if toast_tween != null and toast_tween.is_valid():
		toast_tween.kill()
	toast_tween = create_tween()
	toast_tween.tween_property(toast_panel, "modulate:a", 1.0, 0.3)
	toast_tween.tween_interval(toast_seconds)
	toast_tween.tween_property(toast_panel, "modulate:a", 0.0, 0.6)


# ====================== USE THESE FROM YOUR STORY SCRIPTS ======================
func _add_message(contact: String, text: String, from_me: bool):
	var conv = conversations.get(contact, {"messages": [], "unread": 0})
	conversations.erase(contact)    # put it last so the newest conversation is on top
	conv["messages"].append({"from_me": from_me, "text": text, "time": _now()})
	conversations[contact] = conv


func _is_viewing(contact: String) -> bool:
	return is_open and screen == "conversation" and screen_arg == contact


# a message arrives from someone (optionally after a delay in seconds)
func receive_message(contact: String, text: String, delay: float = 0.0):
	if delay > 0.0:
		await get_tree().create_timer(delay).timeout
	_add_message(contact, text, false)

	if _is_viewing(contact):
		_show("conversation", contact)
	else:
		conversations[contact]["unread"] += 1
		_update_badges()
		if is_open and (screen == "home" or screen == "messages"):
			_show(screen, screen_arg)
		_show_toast(contact, text)
		if notification_sound != null:
			player.play()
	message_received.emit(contact, text)


# a message the player sends
func send_message(contact: String, text: String):
	_add_message(contact, text, true)
	if _is_viewing(contact):
		_show("conversation", contact)
	message_sent.emit(contact, text)


# shows answers the player can tap in that conversation, then emits choice_made
func show_choices(contact: String, options: Array):
	if not conversations.has(contact):
		conversations[contact] = {"messages": [], "unread": 0}
	pending_choices[contact] = options
	if _is_viewing(contact):
		_show("conversation", contact)


func _pick_choice(contact, i: int):
	var options = pending_choices.get(contact, [])
	if i >= options.size():
		return
	var text = str(options[i])
	pending_choices.erase(contact)
	send_message(contact, text)
	choice_made.emit(contact, i, text)


func add_note(title: String, text: String):
	notes.append({"title": title, "text": text, "time": _now()})
	_show_toast("Notes", title)
	if is_open and screen == "notes":
		_show("notes")
	note_added.emit(title)


# adds an app icon on the home screen. on_open is a function that runs when the app is tapped
func add_app(app_id: String, app_name: String, icon: Texture2D, on_open: Callable):
	custom_apps.append({"id": app_id, "name": app_name, "icon": icon, "on_open": on_open})
	if is_open and screen == "home":
		_show("home")


func set_signal_bars(bars: int):
	signal_bars = clampi(bars, 0, 4)
	_update_status()


func set_battery(value: float):
	var was_dead = battery <= 0.0
	battery = clampf(value, 0.0, 100.0)
	battery_changed.emit(battery)
	if is_open and was_dead and battery > 0.0:
		_show("home")
	elif is_open and battery <= 0.0:
		_show(screen, screen_arg)
	_update_status()


func charge(amount: float):
	set_battery(battery + amount)


func is_phone_open() -> bool:
	return is_open


func get_unread() -> int:
	return _total_unread()


# ====================== INPUT ======================
func _unhandled_input(event):
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == toggle_key:
			toggle_phone()
			get_viewport().set_input_as_handled()
		elif is_open and event.keycode == KEY_ESCAPE:
			close_phone()
			get_viewport().set_input_as_handled()


func _input(event):
	if not test_keys:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_F1:
				receive_message("Unknown", "Test message.")
			KEY_F2:
				show_choices("Unknown", ["Who is this?", "Wrong number."])
			KEY_F3:
				add_note("Test note", "This is a test note.")
			KEY_F4:
				charge(-20)
