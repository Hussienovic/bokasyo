extends Sprite2D

signal hovered(obj)
signal unhovered(obj)
signal clicked(obj)

# ---------------- COLOR ----------------
@export_group("Color")
@export var bw_until_hover := true      # on = black and white until the mouse is on it
@export var fade_time := 0.15           # seconds for the color to fade in (0 = instant)

# ---------------- TEXT (hover box) ----------------
@export_group("Text")
@export var title := "Table"
@export_multiline var info := "An old wooden table."
@export var title_color := Color.WHITE
@export var info_color := Color(0.85, 0.85, 0.85)
@export var title_font_size := 22
@export var info_font_size := 16
@export var font: Font

# ---------------- INFO BOX (hover box design) ----------------
@export_group("Info Box")
@export var box_width := 260.0
@export var box_color := Color(0.05, 0.05, 0.08, 0.9)
@export var border_color := Color(1.0, 0.9, 0.3)
@export var border_width := 2
@export var corner_radius := 8
@export var padding := 12
@export var box_offset := Vector2(25, 15)
@export var follow_mouse := true   # off = box stays beside the object

# ---------------- OUTLINE / HIGHLIGHT ----------------
@export_group("Outline")
@export var outline_enabled := true
@export var outline_color := Color(1.0, 0.9, 0.3)
@export var outline_width := 4.0
@export var highlight_brightness := 1.0   # 1 = off, 1.3 = brighter on hover

# ---------------- NOTE (opens on click) ----------------
@export_group("Note (opens on click)")
@export var clickable := false
@export var note_image: Texture2D            # your open-note PNG (leave empty to use the paper box)
@export var note_image_scale := 1.0          # make the picture bigger or smaller
@export var note_text_margin := 40.0         # space around text written on the picture
@export var note_title := "Note"             # only used by the paper box
@export_multiline var note_text := ""        # with a picture: text written on it. Empty = none
@export var close_text := "Close"            # only used by the paper box
@export var note_width := 360.0
@export var note_padding := 20
@export var note_color := Color(0.96, 0.9, 0.7)
@export var note_border_color := Color(0.4, 0.28, 0.12)
@export var note_border_width := 3
@export var note_corner_radius := 6
@export var note_text_color := Color(0.2, 0.12, 0.05)
@export var note_title_font_size := 26
@export var note_font_size := 18
@export var note_font: Font
@export var background_color := Color.BLACK   # color behind the note
@export_range(0.0, 1.0) var dim_background := 1.0   # 1 = fully solid, 0.5 = half see-through

const BW_SHADER := """
shader_type canvas_item;

uniform float strength : hint_range(0.0, 1.0) = 1.0;

void fragment() {
    vec4 c = COLOR;
    float g = dot(c.rgb, vec3(0.299, 0.587, 0.114));
    COLOR = vec4(mix(c.rgb, vec3(g), strength), c.a);
}
"""

var img: Image
var is_hover := false
var outlines: Array = []
var base_modulate: Color

# color effect
var bw_mat: ShaderMaterial
var tween: Tween

# outline node (drawn on top, always in color)
var outline_node: Node2D

# hover box nodes
var layer: CanvasLayer
var panel: PanelContainer
var title_label: Label
var info_label: Label

# note nodes
var note_layer: CanvasLayer
var note_root: Control


func _ready():
	base_modulate = modulate
	img = texture.get_image()

	var bm = BitMap.new()
	bm.create_from_image_alpha(img, 0.1)
	outlines = bm.opaque_to_polygons(Rect2i(Vector2i.ZERO, bm.get_size()), 1.5)

	if bw_until_hover:
		var sh = Shader.new()
		sh.code = BW_SHADER
		bw_mat = ShaderMaterial.new()
		bw_mat.shader = sh
		bw_mat.set_shader_parameter("strength", 1.0)
		material = bw_mat

	outline_node = Node2D.new()
	add_child(outline_node)
	outline_node.draw.connect(_draw_outline)

	_build_panel()
	if clickable:
		_build_note()


# ====================== COLOR FADE ======================
func _fade_color(target: float):
	if bw_mat == null:
		return
	if tween != null and tween.is_valid():
		tween.kill()
	if fade_time <= 0.0:
		bw_mat.set_shader_parameter("strength", target)
		return
	var from = float(bw_mat.get_shader_parameter("strength"))
	tween = create_tween()
	tween.tween_method(func(v): bw_mat.set_shader_parameter("strength", v), from, target, fade_time)


# ====================== HOVER BOX ======================
func _build_panel():
	layer = CanvasLayer.new()
	layer.layer = 100
	add_child(layer)

	panel = PanelContainer.new()
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.visible = false
	panel.custom_minimum_size.x = box_width
	layer.add_child(panel)

	var sb = StyleBoxFlat.new()
	sb.bg_color = box_color
	sb.border_color = border_color
	sb.set_border_width_all(border_width)
	sb.set_corner_radius_all(corner_radius)
	sb.set_content_margin_all(padding)
	panel.add_theme_stylebox_override("panel", sb)

	var vbox = VBoxContainer.new()
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(vbox)

	title_label = _make_label(title_color, title_font_size, box_width - padding * 2, font)
	info_label = _make_label(info_color, info_font_size, box_width - padding * 2, font)
	vbox.add_child(title_label)
	vbox.add_child(info_label)


func _make_label(color: Color, size: int, width: float, f: Font) -> Label:
	var l = Label.new()
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size.x = width
	l.add_theme_color_override("font_color", color)
	l.add_theme_font_size_override("font_size", size)
	if f:
		l.add_theme_font_override("font", f)
	return l


# ====================== NOTE ======================
func _build_note():
	note_layer = CanvasLayer.new()
	note_layer.layer = 110
	add_child(note_layer)

	note_root = Control.new()
	note_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	note_root.visible = false
	note_layer.add_child(note_root)
	note_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# background behind the note, click it to close
	var dim = ColorRect.new()
	dim.color = Color(background_color.r, background_color.g, background_color.b, dim_background)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	dim.gui_input.connect(_on_dim_input)
	note_root.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center = CenterContainer.new()
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	note_root.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	if note_image != null:
		_build_note_image(center)
	else:
		_build_note_panel(center)


# --- note made from your PNG ---
func _build_note_image(parent: Control):
	var tex_size = note_image.get_size() * note_image_scale
	var max_size = get_viewport().get_visible_rect().size * 0.95
	var k = minf(1.0, minf(max_size.x / tex_size.x, max_size.y / tex_size.y))
	tex_size *= k

	var pic = TextureRect.new()
	pic.texture = note_image
	pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	pic.custom_minimum_size = tex_size
	pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(pic)

	if note_text != "":
		var f = note_font if note_font else font
		var lbl = _make_label(note_text_color, note_font_size, 0.0, f)
		lbl.text = note_text
		pic.add_child(lbl)
		lbl.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		var m = note_text_margin * k
		lbl.offset_left = m
		lbl.offset_top = m
		lbl.offset_right = -m
		lbl.offset_bottom = -m


# --- note made from the paper box ---
func _build_note_panel(parent: Control):
	var np = PanelContainer.new()
	np.mouse_filter = Control.MOUSE_FILTER_STOP
	np.custom_minimum_size.x = note_width
	parent.add_child(np)

	var sb = StyleBoxFlat.new()
	sb.bg_color = note_color
	sb.border_color = note_border_color
	sb.set_border_width_all(note_border_width)
	sb.set_corner_radius_all(note_corner_radius)
	sb.set_content_margin_all(note_padding)
	np.add_theme_stylebox_override("panel", sb)

	var vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	np.add_child(vbox)

	var f = note_font if note_font else font
	var inner_width = note_width - note_padding * 2

	var t = _make_label(note_text_color, note_title_font_size, inner_width, f)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.text = note_title
	t.visible = note_title != ""
	vbox.add_child(t)

	var body = _make_label(note_text_color, note_font_size, inner_width, f)
	body.text = note_text
	body.visible = note_text != ""
	vbox.add_child(body)

	var btn = Button.new()
	btn.text = close_text
	btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	btn.pressed.connect(_close_note)
	vbox.add_child(btn)


func _open_note():
	if note_root == null:
		return
	_set_hover(false)
	note_root.visible = true
	add_to_group("note_open")


func _close_note():
	if note_root == null:
		return
	note_root.visible = false
	remove_from_group("note_open")


func _on_dim_input(event):
	if event is InputEventMouseButton and event.pressed:
		_close_note()


# ====================== HOVER LOGIC ======================
func _process(_delta):
	if not is_visible_in_tree() or get_tree().has_group("note_open"):
		if is_hover:
			_set_hover(false)
		return

	var over = _is_mouse_over()
	if over and not is_hover:
		_set_hover(true)
	elif not over and is_hover:
		_set_hover(false)

	if is_hover:
		_position_panel()


func _is_mouse_over() -> bool:
	var r = get_rect()
	var local = to_local(get_global_mouse_position())
	if not r.has_point(local):
		return false
	var p = local - r.position
	var x = int(p.x)
	var y = int(p.y)
	if x < 0 or y < 0 or x >= img.get_width() or y >= img.get_height():
		return false
	return img.get_pixel(x, y).a > 0.1


func _set_hover(on: bool):
	is_hover = on
	if on:
		title_label.text = title
		title_label.visible = title != ""
		info_label.text = info
		info_label.visible = info != ""
		panel.reset_size()
		panel.visible = true
		var b = highlight_brightness
		modulate = Color(base_modulate.r * b, base_modulate.g * b, base_modulate.b * b, base_modulate.a)
		hovered.emit(self)
	else:
		panel.visible = false
		modulate = base_modulate
		unhovered.emit(self)

	_fade_color(0.0 if on else 1.0)

	if clickable:
		Input.set_default_cursor_shape(Input.CURSOR_POINTING_HAND if on else Input.CURSOR_ARROW)
	if outline_node:
		outline_node.queue_redraw()


func _position_panel():
	var screen = get_viewport().get_visible_rect().size
	var pos: Vector2
	if follow_mouse:
		pos = get_viewport().get_mouse_position() + box_offset
	else:
		var r = get_rect()
		pos = get_global_transform_with_canvas() * Vector2(r.end.x, r.position.y) + box_offset
	pos.x = clampf(pos.x, 0.0, maxf(0.0, screen.x - panel.size.x))
	pos.y = clampf(pos.y, 0.0, maxf(0.0, screen.y - panel.size.y))
	panel.position = pos


func _draw_outline():
	if not (is_hover and outline_enabled):
		return
	var shift = offset
	if centered:
		shift -= texture.get_size() / 2.0
	for poly in outlines:
		var pts = PackedVector2Array()
		for p in poly:
			pts.append(p + shift)
		if pts.size() > 0:
			pts.append(pts[0])
			outline_node.draw_polyline(pts, outline_color, outline_width, true)


# ====================== INPUT ======================
func _unhandled_input(event):
	# note is open: Esc closes it
	if note_root != null and note_root.visible:
		if event.is_action_pressed("ui_cancel"):
			_close_note()
		return

	if is_hover and event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		clicked.emit(self)
		if clickable:
			_open_note()
			get_viewport().set_input_as_handled()
