Files the game does not use (old copies and unused images).
Godot ignores this folder. Delete it when you are happy with the project.
