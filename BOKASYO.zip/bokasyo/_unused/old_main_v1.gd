extends Node2D

@export var start_room := 0
@export var fade_time := 0.2            # fade to black between rooms (0 = instant)

@export_group("Top Bar")
@export_enum("Top Left", "Top Right", "Bottom Left", "Bottom Right", "Center Left", "Top Center", "Center Right", "Bottom Center", "Center") var bar_position := 5
@export var bar_offset := Vector2(0, 0)      # move the bar more (pixels)
@export var vertical_bar := false            # on = boxes in a column
@export var bar_margin := 10                 # space from the screen edge
@export var button_size := Vector2(48, 48)   # width and height of each button
@export var icon_spacing := 12
@export var bar_padding := 8
@export var bar_color := Color(0.05, 0.05, 0.08, 0.85)
@export var bar_border_color := Color(0.4, 0.4, 0.45)
@export var bar_border_width := 2
@export var bar_corner_radius := 10
@export var icon_inactive_color := Color(0.6, 0.6, 0.6)
@export var icon_hover_color := Color(1.0, 0.95, 0.7)
@export var icon_active_color := Color.WHITE

@export_group("Custom Design")
@export var show_tooltip := false           # on = small text box with room name on hover
@export var text_size := 20                 # size of the room name text (no box)
@export var bar_texture: Texture2D          # your picture behind the boxes (optional)
@export var bar_size := Vector2(0, 0)       # size of that picture (0 = automatic)
@export var bar_texture_margin := 0         # 0 = stretch whole picture, bigger = 9-patch edges
@export var frame_normal: Texture2D         # your icon frame (optional)
@export var frame_hover: Texture2D          # frame when mouse is over (optional)
@export var frame_active: Texture2D         # frame of the current room (optional)
@export var icon_inset := 8                 # space between frame edge and room icon
@export var tint_icons := true              # off = no color change, only your frames

var rooms: Array = []
var buttons: Array = []
var current := -1
var transitioning := false
var fade_rect: ColorRect


func _ready():
	for c in get_children():
		if "room_name" in c:
			rooms.append(c)
	if rooms.is_empty():
		push_warning("main.gd: no rooms found. Add room.gd to your room nodes.")
		return

	_build_fade()
	_build_bar()
	_show_room(clampi(start_room, 0, rooms.size() - 1))


# ====================== TOP BAR ======================
func _build_bar():
	var l = CanvasLayer.new()
	l.layer = 50
	add_child(l)

	# full-screen holder (does not block the mouse)
	var holder = Control.new()
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_child(holder)
	holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var panel = PanelContainer.new()
	panel.custom_minimum_size = bar_size
	if bar_texture != null:
		var sbt = StyleBoxTexture.new()
		sbt.texture = bar_texture
		sbt.set_texture_margin_all(bar_texture_margin)
		sbt.set_content_margin_all(bar_padding)
		panel.add_theme_stylebox_override("panel", sbt)
	else:
		var sb = StyleBoxFlat.new()
		sb.bg_color = bar_color
		sb.border_color = bar_border_color
		sb.set_border_width_all(bar_border_width)
		sb.set_corner_radius_all(bar_corner_radius)
		sb.set_content_margin_all(bar_padding)
		panel.add_theme_stylebox_override("panel", sb)
	holder.add_child(panel)

	# keeps the boxes in the middle of the picture
	var center = CenterContainer.new()
	panel.add_child(center)

	var row = BoxContainer.new()
	row.vertical = vertical_bar
	row.add_theme_constant_override("separation", icon_spacing)
	center.add_child(row)

	for i in rooms.size():
		var r = rooms[i]
		var b: BaseButton
		if frame_normal != null:
			# your own frame + the room icon inside it
			var fb = TextureButton.new()
			fb.texture_normal = frame_normal
			if frame_hover != null:
				fb.texture_hover = frame_hover
			fb.ignore_texture_size = true
			fb.stretch_mode = TextureButton.STRETCH_SCALE
			fb.custom_minimum_size = button_size
			if r.icon != null:
				var pic = TextureRect.new()
				pic.texture = r.icon
				pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
				pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
				pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
				fb.add_child(pic)
				pic.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, icon_inset)
			b = fb
		elif r.icon != null:
			var tb = TextureButton.new()
			tb.texture_normal = r.icon
			tb.ignore_texture_size = true
			tb.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
			tb.custom_minimum_size = button_size
			b = tb
		else:
			# text only: no box behind the room name
			var tb2 = Button.new()
			tb2.text = r.room_name
			tb2.flat = true
			tb2.add_theme_font_size_override("font_size", text_size)
			var empty = StyleBoxEmpty.new()
			tb2.add_theme_stylebox_override("normal", empty)
			tb2.add_theme_stylebox_override("hover", empty)
			tb2.add_theme_stylebox_override("pressed", empty)
			tb2.add_theme_stylebox_override("disabled", empty)
			tb2.add_theme_stylebox_override("focus", empty)
			b = tb2
		if show_tooltip:
			b.tooltip_text = r.room_name
		b.focus_mode = Control.FOCUS_NONE
		b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		b.pressed.connect(_go_to.bind(i))
		b.mouse_entered.connect(_on_icon_hover.bind(i, true))
		b.mouse_exited.connect(_on_icon_hover.bind(i, false))
		row.add_child(b)
		buttons.append(b)

	# put the bar where you chose, then move it by the offset
	panel.set_anchors_and_offsets_preset(bar_position, Control.PRESET_MODE_MINSIZE, bar_margin)
	panel.offset_left += bar_offset.x
	panel.offset_right += bar_offset.x
	panel.offset_top += bar_offset.y
	panel.offset_bottom += bar_offset.y


func _icon_color(i: int) -> Color:
	if not tint_icons:
		return Color.WHITE
	return icon_active_color if i == current else icon_inactive_color


func _on_icon_hover(i: int, on: bool):
	if tint_icons:
		buttons[i].modulate = icon_hover_color if on else _icon_color(i)


func _refresh_icons():
	for i in buttons.size():
		var b = buttons[i]
		b.modulate = _icon_color(i)
		# swap to your "active" frame for the current room
		if b is TextureButton and frame_normal != null:
			if i == current and frame_active != null:
				b.texture_normal = frame_active
			else:
				b.texture_normal = frame_normal


# ====================== ROOMS ======================
func _build_fade():
	var l = CanvasLayer.new()
	l.layer = 40
	add_child(l)
	fade_rect = ColorRect.new()
	fade_rect.color = Color(0, 0, 0, 0)
	fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_child(fade_rect)
	fade_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _show_room(i: int):
	current = i
	for idx in rooms.size():
		rooms[idx].visible = (idx == i)
	_refresh_icons()


func _go_to(i: int):
	if i == current or transitioning:
		return
	transitioning = true

	if fade_time > 0.0:
		var t = create_tween()
		t.tween_property(fade_rect, "color:a", 1.0, fade_time)
		await t.finished

	_show_room(i)

	if fade_time > 0.0:
		var t2 = create_tween()
		t2.tween_property(fade_rect, "color:a", 0.0, fade_time)
		await t2.finished

	transitioning = false
