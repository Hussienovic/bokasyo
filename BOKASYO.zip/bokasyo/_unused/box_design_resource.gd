class_name BoxDesign
extends Resource

# One picture on a box. Add as many as you want to each box.

@export var texture: Texture2D                 # your picture
@export var size := Vector2.ZERO               # 0,0 = fits the whole box. Set only the width (or only the height) to keep the picture ratio
@export var offset := Vector2.ZERO             # moves the picture. Positive = right and down. Negative = left and up
@export var in_front := false                  # off = behind the text. On = on top of the text
@export var tint := Color.WHITE                # color of the picture. Lower the alpha to make it see-through
